import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  constructor(private http: HttpClient) { }

  sendReceive(number) {
    const url = `http://numbersapi.com/${number}?json`
    return this.http.get(url)
    .toPromise().then(response => {
      return response
    }).catch(error=> {
      return Promise.reject(error);
    })
  }
}
