import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetValueComponent } from './get-value.component';

describe('GetValueComponent', () => {
  let component: GetValueComponent;
  let fixture: ComponentFixture<GetValueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetValueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetValueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
