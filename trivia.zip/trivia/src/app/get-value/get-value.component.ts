import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder} from '@angular/forms';
import { Router } from '@angular/router';
import {CommonFunctions} from '../common/common-function'
@Component({
  selector: 'app-get-value',
  templateUrl: './get-value.component.html',
  styleUrls: ['./get-value.component.scss']
})
export class GetValueComponent implements OnInit {

  getValueForm : FormGroup;
  constructor(public formBuilder:FormBuilder,private router: Router, private common: CommonFunctions) { 
    this.getValueForm =  formBuilder.group({
      userValue :['']
    })
  }

  storeValue() {
    // alert(this.getValueForm.get('userValue').value);
    this.common.setNumber({Number: this.getValueForm.get('userValue').value})
    this.router.navigateByUrl('secondScreen');

  }

  ngOnInit() {
  }

}
