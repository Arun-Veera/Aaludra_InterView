import { Component, OnInit } from '@angular/core';
import {CommonFunctions} from '../common/common-function'
import {DataServiceService} from '../data-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-value',
  templateUrl: './show-value.component.html',
  styleUrls: ['./show-value.component.scss']
})
export class ShowValueComponent implements OnInit {

  constructor( private common: CommonFunctions,private router: Router, private service: DataServiceService) { }

  globalValue
  ngOnInit() {
    this.common.getNumber().subscribe(value => {
      console.log(Object.values(value).length)
      this.processvalue(value);
    })
  }

  processvalue(number){
    if(Object.keys(number).length > 0 ){
      this.service.sendReceive(number.Number).then(res => {
        console.log(res);
        this.globalValue = res['text']
      })
    } else {
      alert('Please enter the number');
      this.router.navigateByUrl('firstScreen');
    }
    
  }

}
