import { BehaviorSubject, Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class CommonFunctions {
    number: BehaviorSubject<any> = new BehaviorSubject({});

    setNumber(number) {
        this.number.next(number)
    }

    getNumber() {
        return this.number.asObservable();
    }
}